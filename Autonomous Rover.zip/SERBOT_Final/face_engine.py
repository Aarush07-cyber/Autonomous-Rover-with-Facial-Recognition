"""SERBOT face detection and local template matching.

Prototype only: this is not biometric-grade face recognition. It uses
OpenCV Haar face detection and normalized grayscale correlation.
"""
from pathlib import Path
import cv2
import numpy as np


class FaceEngine:
    def __init__(self, known_dir="known_faces", threshold=0.62):
        self.known_dir = Path(known_dir)
        self.known_dir.mkdir(parents=True, exist_ok=True)
        self.threshold = float(threshold)

        cascade_path = (
            "/usr/share/opencv4/haarcascades/"
            "haarcascade_frontalface_default.xml"
        )
        self.detector = cv2.CascadeClassifier(cascade_path)
        if self.detector.empty():
            raise RuntimeError(f"Could not load Haar cascade: {cascade_path}")

        self.known = {}
        self.reload_known()

    @staticmethod
    def _normalise(face):
        """Apply identical preprocessing to enrolled and live face crops."""
        face = cv2.resize(face, (100, 100), interpolation=cv2.INTER_AREA)
        face = cv2.equalizeHist(face)
        face = cv2.GaussianBlur(face, (3, 3), 0)
        arr = face.astype(np.float32)
        arr = (arr - arr.mean()) / (arr.std() + 1e-6)
        return arr.reshape(-1)

    def reload_known(self):
        self.known.clear()
        for path in sorted(self.known_dir.glob("*.npz")):
            try:
                with np.load(path) as data:
                    samples = data["samples"].astype(np.float32)
                if samples.ndim == 2 and samples.shape[1] == 10000:
                    self.known[path.stem] = samples
                    print(f"Loaded {len(samples)} face samples for {path.stem}")
            except Exception as exc:
                print(f"Skipping invalid enrollment {path.name}: {exc}")

    def detect(self, frame):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self.detector.detectMultiScale(
            gray,
            scaleFactor=1.10,
            minNeighbors=4,
            minSize=(55, 55),
            flags=cv2.CASCADE_SCALE_IMAGE,
        )

        results = []
        for (x, y, w, h) in faces:
            # Use the exact Haar bounding box. enroll.py uses the same crop.
            crop = gray[y:y + h, x:x + w]
            if crop.size == 0:
                continue
            feature = self._normalise(crop)
            name, score = self.identify(feature)
            results.append({
                "box": (int(x), int(y), int(w), int(h)),
                "name": name,
                "score": float(score),
                "state": "KNOWN" if name != "UNKNOWN" else "UNKNOWN",
            })
        return results

    def identify(self, feature):
        if not self.known:
            return "UNKNOWN", 0.0

        feature = feature.astype(np.float32)
        feature = feature / (np.linalg.norm(feature) + 1e-8)

        best_name = "UNKNOWN"
        best_score = -1.0

        for name, samples in self.known.items():
            # Correlation/cosine similarity; compare against every enrollment
            # sample and use the strongest match.
            samples = samples.astype(np.float32)
            norms = np.linalg.norm(samples, axis=1, keepdims=True) + 1e-8
            normalised_samples = samples / norms
            scores = normalised_samples @ feature
            score = float(np.max(scores))
            if score > best_score:
                best_name, best_score = name, score

        if best_score < self.threshold:
            return "UNKNOWN", best_score
        return best_name, best_score

    def add_enrollment_sample(self, name, face_gray):
        safe_name = "".join(
            c for c in name.strip() if c.isalnum() or c in ("_", "-")
        )
        if not safe_name:
            raise ValueError("Name must contain letters or numbers")

        feature = self._normalise(face_gray)
        path = self.known_dir / f"{safe_name}.npz"

        if path.exists():
            with np.load(path) as data:
                old = data["samples"].astype(np.float32)
            samples = np.vstack([old, feature])
        else:
            samples = feature.reshape(1, -1)

        np.savez_compressed(path, samples=samples)
        self.known[safe_name] = samples
        return safe_name

    def annotate(self, frame, detections):
        for item in detections:
            x, y, w, h = item["box"]
            known = item["state"] == "KNOWN"
            colour = (40, 200, 80) if known else (30, 80, 240)
            label = item["name"] if known else "UNKNOWN"
            cv2.rectangle(frame, (x, y), (x + w, y + h), colour, 2)
            cv2.putText(
                frame,
                f"{label} {item['score']:.2f}",
                (x, max(22, y - 8)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                colour,
                2,
                cv2.LINE_AA,
            )
        return frame

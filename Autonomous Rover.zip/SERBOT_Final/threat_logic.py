"""Per-track identity confirmation and one-shot unknown-face alerts."""
from collections import defaultdict


class ThreatLogic:
    def __init__(self, known_confirm=3, unknown_confirm=6, forget_after=15):
        self.known_confirm = int(known_confirm)
        self.unknown_confirm = int(unknown_confirm)
        self.forget_after = int(forget_after)
        self.counts = defaultdict(int)
        self.last_labels = {}
        self.states = {}
        self.alerted = set()
        self.missed = defaultdict(int)

    def update(self, track_key, label, now=None):
        """Return (stable_state, should_alert)."""
        self.missed[track_key] = 0

        if label not in ("KNOWN", "UNKNOWN"):
            self.counts[track_key] = 0
            self.last_labels.pop(track_key, None)
            self.states[track_key] = "NO_FACE"
            return "NO_FACE", False

        # Confirmation must be consecutive for the same classification.
        if self.last_labels.get(track_key) != label:
            self.counts[track_key] = 1
            self.last_labels[track_key] = label
        else:
            self.counts[track_key] += 1

        required = self.known_confirm if label == "KNOWN" else self.unknown_confirm
        if self.counts[track_key] < required:
            return "CHECKING", False

        self.states[track_key] = label
        should_alert = False
        if label == "UNKNOWN" and track_key not in self.alerted:
            self.alerted.add(track_key)
            should_alert = True

        return label, should_alert

    def forget_missing(self, active_keys):
        """Keep state through brief dropouts; forget only after grace frames."""
        active = set(active_keys)
        all_keys = (
            set(self.counts) | set(self.states) |
            set(self.missed) | set(self.alerted)
        )
        for key in all_keys:
            if key in active:
                self.missed[key] = 0
            else:
                self.missed[key] += 1
                if self.missed[key] > self.forget_after:
                    self.counts.pop(key, None)
                    self.last_labels.pop(key, None)
                    self.states.pop(key, None)
                    self.missed.pop(key, None)
                    self.alerted.discard(key)

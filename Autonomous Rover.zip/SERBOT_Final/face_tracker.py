"""More tolerant face-box tracker for SERBOT.

Keeps IDs across brief detector dropouts and small bounding-box changes.
This is visual tracking only; it never sends motor commands.
"""
from collections import OrderedDict
import math


def box_iou(a, b):
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    x1, y1 = max(ax, bx), max(ay, by)
    x2, y2 = min(ax + aw, bx + bw), min(ay + ah, by + bh)
    iw, ih = max(0, x2 - x1), max(0, y2 - y1)
    inter = iw * ih
    union = aw * ah + bw * bh - inter
    return inter / union if union > 0 else 0.0


def center_and_size(box):
    x, y, w, h = box
    return (x + w / 2.0, y + h / 2.0), (w, h)


class FaceTracker:
    def __init__(self, max_missed=15, min_iou=0.03,
                 max_center_distance=1.25, max_size_ratio=2.8):
        self.max_missed = int(max_missed)
        self.min_iou = float(min_iou)
        self.max_center_distance = float(max_center_distance)
        self.max_size_ratio = float(max_size_ratio)
        self.next_id = 1
        self.tracks = OrderedDict()

    def _match_score(self, det_box, old_box):
        iou = box_iou(det_box, old_box)
        (dcx, dcy), (dw, dh) = center_and_size(det_box)
        (tcx, tcy), (tw, th) = center_and_size(old_box)

        # Normalize centre movement by average face-box diagonal.
        scale = max(1.0, (math.hypot(dw, dh) + math.hypot(tw, th)) / 2.0)
        distance = math.hypot(dcx - tcx, dcy - tcy) / scale

        size_ratio_w = max(dw, tw) / max(1.0, min(dw, tw))
        size_ratio_h = max(dh, th) / max(1.0, min(dh, th))
        size_ratio = max(size_ratio_w, size_ratio_h)

        if distance > self.max_center_distance or size_ratio > self.max_size_ratio:
            return None

        # IoU is useful when boxes overlap; centre distance handles box jitter.
        proximity = max(0.0, 1.0 - distance / self.max_center_distance)
        return 0.55 * iou + 0.45 * proximity

    def update(self, detections):
        candidates = []
        for det_index, det in enumerate(detections):
            for track_id, track in self.tracks.items():
                score = self._match_score(det["box"], track["box"])
                if score is not None:
                    candidates.append((score, det_index, track_id))

        candidates.sort(reverse=True)
        used_detections = set()
        used_tracks = set()
        assignments = {}

        for score, det_index, track_id in candidates:
            if det_index in used_detections or track_id in used_tracks:
                continue
            used_detections.add(det_index)
            used_tracks.add(track_id)
            assignments[det_index] = track_id

        for index, det in enumerate(detections):
            track_id = assignments.get(index)
            if track_id is None:
                track_id = self.next_id
                self.next_id += 1

            box = tuple(int(v) for v in det["box"])
            self.tracks[track_id] = {"box": box, "missed": 0}
            x, y, w, h = box
            det["track_id"] = track_id
            det["center"] = (int(x + w / 2), int(y + h / 2))

        # A face can disappear for a few processed frames due to detector jitter.
        for track_id in list(self.tracks.keys()):
            if track_id not in used_tracks and track_id not in assignments.values():
                self.tracks[track_id]["missed"] += 1
                if self.tracks[track_id]["missed"] > self.max_missed:
                    del self.tracks[track_id]

        return detections

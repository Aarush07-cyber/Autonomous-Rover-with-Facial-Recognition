from flask import Flask, Response, render_template_string, request, jsonify
import atexit
import cv2
import serial
import threading
import time
from collections import deque
from face_engine import FaceEngine
from threat_logic import ThreatLogic
from face_tracker import FaceTracker

app = Flask(__name__)

SERIAL_PORT = "/dev/serial/by-id/usb-Arduino__www.arduino.cc__Arduino_14101-if00"
BAUD_RATE = 9600

camera = cv2.VideoCapture(0, cv2.CAP_V4L2)
camera.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
camera.set(cv2.CAP_PROP_FPS, 30)

arduino = None
serial_lock = threading.Lock()
mode_lock = threading.Lock()
robot_mode = "MANUAL"  # Always start in manual mode

# Recognition runs on the same camera frames used by the dashboard.
face_engine = FaceEngine(known_dir="known_faces")
threat_logic = ThreatLogic(known_confirm=3, unknown_confirm=6, forget_after=15)
face_tracker = FaceTracker(max_missed=15, min_iou=0.03, max_center_distance=1.25, max_size_ratio=2.8)
recognition_lock = threading.Lock()
recognition_state = {
    "faces": [],
    "last_alert": "No alerts",
    "alerts": deque(maxlen=20),
    "frames_processed": 0,
    "selected_target_id": None,
    "target_missed_frames": 0
}
latest_frame_lock = threading.Lock()
latest_frame = None
face_engine_lock = threading.Lock()

try:
    arduino = serial.Serial(
        SERIAL_PORT, BAUD_RATE, timeout=0.1, write_timeout=0.2
    )
    time.sleep(2)  # Arduino Uno resets when serial port opens
    arduino.reset_input_buffer()
    print("Arduino connected:", SERIAL_PORT)
except Exception as exc:
    print("Arduino connection failed:", exc)

ALLOWED_COMMANDS = {"FORWARD", "BACKWARD", "LEFT", "RIGHT", "STOP"}


def send_motor_command(command):
    if command not in ALLOWED_COMMANDS:
        return False, "Invalid command"

    if arduino is None or not arduino.is_open:
        return False, "Arduino is not connected"

    try:
        with serial_lock:
            arduino.write((command + "\n").encode("utf-8"))
            arduino.flush()
        print("Motor command:", command)
        return True, "Command sent"
    except Exception as exc:
        print("Serial error:", exc)
        return False, str(exc)


@app.route("/control", methods=["POST"])
def control():
    data = request.get_json(silent=True) or {}
    command = str(data.get("command", "")).upper()

    with mode_lock:
        current_mode = robot_mode

    # The browser joystick is accepted only in MANUAL mode.
    if current_mode != "MANUAL" and command != "STOP":
        return jsonify({
            "success": False,
            "message": "Manual controls are disabled in Autonomous mode"
        }), 409

    success, message = send_motor_command(command)
    return jsonify({"success": success, "message": message}), (
        200 if success else 503
    )


@app.route("/mode", methods=["POST"])
def set_mode():
    global robot_mode
    data = request.get_json(silent=True) or {}
    requested = str(data.get("mode", "")).upper()

    if requested not in {"MANUAL", "AUTONOMOUS"}:
        return jsonify({"success": False, "message": "Invalid mode"}), 400

    # Stop before changing modes so no previous movement carries over.
    success, message = send_motor_command("STOP")
    if not success:
        return jsonify({"success": False, "message": message}), 503

    with mode_lock:
        robot_mode = requested

    if requested == "AUTONOMOUS":
        message = (
            "Autonomous monitoring active. Face detection and alerts are enabled; "
            "motor movement remains disabled for safety."
        )
    else:
        message = "Manual mode active."

    print("Robot mode:", requested)
    return jsonify({
        "success": True,
        "mode": requested,
        "message": message
    })


@app.route("/status")
def status():
    connected = arduino is not None and arduino.is_open
    with mode_lock:
        current_mode = robot_mode
    with recognition_lock:
        face_count = len(recognition_state["faces"])
        last_alert = recognition_state["last_alert"]

    return jsonify({
        "arduino": "connected" if connected else "disconnected",
        "camera": camera.isOpened(),
        "mode": current_mode,
        "recognition": "online",
        "faces_detected": face_count,
        "last_alert": last_alert,
        # Autonomous mode is monitoring-only until separately safety-tested.
        "autonomous_ready": False
    })


@app.route("/api/recognition")
def recognition_status():
    with recognition_lock:
        return jsonify({
            "faces": recognition_state["faces"],
            "last_alert": recognition_state["last_alert"],
            "alerts": list(recognition_state["alerts"]),
            "known_people": sorted(face_engine.known.keys()),
            "selected_target_id": recognition_state["selected_target_id"],
            "target_missed_frames": recognition_state["target_missed_frames"]
        })


@app.route("/api/target/select", methods=["POST"])
def select_target():
    data = request.get_json(silent=True) or {}
    try:
        track_id = int(data.get("track_id"))
    except (TypeError, ValueError):
        return jsonify({"success": False, "message": "Invalid tracking ID"}), 400

    with recognition_lock:
        visible_ids = {int(face["track_id"]) for face in recognition_state["faces"]}
        if track_id not in visible_ids:
            return jsonify({
                "success": False,
                "message": "That face is no longer visible. Select a currently visible face."
            }), 409
        recognition_state["selected_target_id"] = track_id
        recognition_state["target_missed_frames"] = 0

    return jsonify({
        "success": True,
        "selected_target_id": track_id,
        "message": f"Target #{track_id} selected for monitoring only."
    })


@app.route("/api/target/release", methods=["POST"])
def release_target():
    with recognition_lock:
        recognition_state["selected_target_id"] = None
        recognition_state["target_missed_frames"] = 0
    return jsonify({"success": True, "message": "Target released."})


@app.route("/api/reload_faces", methods=["POST"])
def reload_faces():
    with face_engine_lock:
        face_engine.reload_known()
        known_people = sorted(face_engine.known.keys())
    return jsonify({"success": True, "known_people": known_people})


@app.route("/api/enroll/capture", methods=["POST"])
def enroll_capture():
    """Capture one face sample from the live webcam frame and save it."""
    data = request.get_json(silent=True) or {}
    raw_name = str(data.get("name", "")).strip()
    safe_name = "".join(
        char for char in raw_name if char.isalnum() or char in ("_", "-")
    )
    if not safe_name:
        return jsonify({
            "success": False,
            "message": "Enter a name using letters, numbers, hyphens or underscores."
        }), 400

    with latest_frame_lock:
        frame = None if latest_frame is None else latest_frame.copy()

    if frame is None:
        return jsonify({
            "success": False,
            "message": "Camera frame is not ready yet. Wait a moment and try again."
        }), 503

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    try:
        with face_engine_lock:
            faces = face_engine.detector.detectMultiScale(
                gray,
                scaleFactor=1.10,
                minNeighbors=4,
                minSize=(55, 55),
                flags=cv2.CASCADE_SCALE_IMAGE
            )

            if len(faces) == 0:
                return jsonify({
                    "success": False,
                    "message": "No face detected. Move closer, face the camera and try again."
                }), 400

            if len(faces) > 1:
                return jsonify({
                    "success": False,
                    "message": "More than one face detected. Keep only the person being enrolled in the frame."
                }), 400

            x, y, w, h = [int(value) for value in faces[0]]
            face_crop = gray[y:y + h, x:x + w]
            if face_crop.size == 0:
                return jsonify({
                    "success": False,
                    "message": "Face crop was empty. Please try again."
                }), 400

            saved_name = face_engine.add_enrollment_sample(safe_name, face_crop)
            sample_count = int(face_engine.known[saved_name].shape[0])
            known_people = sorted(face_engine.known.keys())

        return jsonify({
            "success": True,
            "name": saved_name,
            "sample_count": sample_count,
            "known_people": known_people,
            "message": f"Saved sample {sample_count} for {saved_name}."
        })
    except Exception as exc:
        print("Website enrollment error:", exc)
        return jsonify({
            "success": False,
            "message": "Enrollment failed. Check the Raspberry Pi terminal."
        }), 500


def generate_frames():
    frame_number = 0
    while True:
        success, frame = camera.read()
        if not success:
            time.sleep(0.05)
            continue

        with latest_frame_lock:
            global latest_frame
            latest_frame = frame.copy()

        frame_number += 1
        if frame_number % 2 == 0:
            try:
                with face_engine_lock:
                    detections = face_engine.detect(frame)

                detections = face_tracker.update(detections)
                current_faces = []
                active_keys = []

                for item in detections:
                    track_id = item["track_id"]
                    key = f"face-track-{track_id}"
                    active_keys.append(key)
                    stable_state, alert = threat_logic.update(key, item["state"])
                    item["stable_state"] = stable_state

                    x, y = item["center"]
                    offset_x = x - (frame.shape[1] // 2)
                    offset_y = y - (frame.shape[0] // 2)
                    item["center_offset"] = (offset_x, offset_y)

                    current_faces.append({
                        "track_id": track_id,
                        "name": item["name"],
                        "state": stable_state,
                        "raw_state": item["state"],
                        "score": round(item["score"], 3),
                        "center_x": x,
                        "center_y": y,
                        "offset_x": offset_x,
                        "offset_y": offset_y
                    })

                    if alert:
                        message = (
                            f"Unrecognized face on track #{track_id} "
                            f"(score {item['score']:.2f})"
                        )
                        with recognition_lock:
                            recognition_state["last_alert"] = message
                            recognition_state["alerts"].appendleft({
                                "time": time.strftime("%H:%M:%S"),
                                "message": message
                            })
                        print("[SERBOT ALERT]", message)

                threat_logic.forget_missing(active_keys)
                face_engine.annotate(frame, detections)
                for item in detections:
                    x, y, w, h = item["box"]
                    cv2.putText(
                        frame, f"ID {item['track_id']}",
                        (x, min(frame.shape[0] - 8, y + h + 20)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55,
                        (255, 220, 0), 2, cv2.LINE_AA
                    )

                with recognition_lock:
                    recognition_state["faces"] = current_faces
                    recognition_state["frames_processed"] += 1
                    selected_id = recognition_state["selected_target_id"]
                    if selected_id is not None:
                        visible_ids = {face["track_id"] for face in current_faces}
                        if selected_id in visible_ids:
                            recognition_state["target_missed_frames"] = 0
                        else:
                            recognition_state["target_missed_frames"] += 1
                            # Recognition runs on every second camera frame.
                            # 75 processed frames is roughly five seconds at 30 FPS.
                            if recognition_state["target_missed_frames"] >= 75:
                                print(f"[SERBOT] Target #{selected_id} lost; releasing lock.")
                                recognition_state["selected_target_id"] = None
                                recognition_state["target_missed_frames"] = 0
            except Exception as exc:
                cv2.putText(frame, "AI ERROR - check terminal",
                            (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7,
                            (0, 0, 255), 2)
                print("Face processing error:", exc)

        with mode_lock:
            current_mode = robot_mode
        cv2.putText(frame, f"SERBOT | {current_mode} | MONITORING",
                    (10, frame.shape[0] - 15), cv2.FONT_HERSHEY_SIMPLEX,
                    0.55, (255, 255, 255), 2, cv2.LINE_AA)

        ok, buffer = cv2.imencode(
            ".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 80]
        )
        if not ok:
            continue
        yield (
            b"--frame\r\n"
            b"Content-Type: image/jpeg\r\n\r\n"
            + buffer.tobytes()
            + b"\r\n"
        )


HTML = r"""
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SERBOT - Robot Control</title>
<style>
* { box-sizing: border-box; }
body {
    margin: 0; padding: 20px; background: #101827; color: white;
    font-family: Arial, sans-serif; text-align: center;
}
.dashboard { max-width: 1000px; margin: auto; }
h1 { color: #38bdf8; }
.panel {
    background: #1e293b; padding: 18px; border-radius: 14px;
    margin: 15px auto;
}
.camera {
    width: 100%; max-width: 800px; border: 2px solid #38bdf8;
    border-radius: 12px;
}
.status {
    display: flex; justify-content: center; gap: 20px;
    flex-wrap: wrap; margin: 15px;
}
.connected { color: #4ade80; }
.disconnected { color: #f87171; }
.joystick-area { display: flex; justify-content: center; padding: 15px; }
#joystick {
    width: 250px; height: 250px; border-radius: 50%;
    background: #334155; border: 4px solid #64748b;
    position: relative; touch-action: none; user-select: none;
}
#stick {
    width: 85px; height: 85px; border-radius: 50%;
    background: #38bdf8; border: 4px solid #bae6fd;
    position: absolute; left: 50%; top: 50%;
    transform: translate(-50%, -50%);
    box-shadow: 0 4px 15px #0008; pointer-events: none;
}
.hint { color: #94a3b8; font-size: 13px; line-height: 1.5; }
button {
    color: white; border: 0; border-radius: 10px;
    padding: 12px 20px; cursor: pointer; margin: 5px;
}
button:disabled { opacity: .4; cursor: not-allowed; }
input:focus { outline: 2px solid #38bdf8; }
#stopButton { background: #dc2626; padding: 16px 35px; font-size: 18px; font-weight: bold; }
#fullscreenButton { background: #0284c7; }
.modeButton { background: #475569; min-width: 150px; }
.modeButton.selected { background: #0284c7; outline: 2px solid #7dd3fc; }
#modeMessage { color: #fbbf24; min-height: 20px; }
#joystick.disabled { opacity: .35; pointer-events: none; }
@media(max-width: 500px) {
    #joystick { width: 220px; height: 220px; }
}
</style>
</head>
<body>
<div class="dashboard">
    <h1>SERBOT CONTROL</h1>
    <p>Raspberry Pi 5 Robot Dashboard</p>

    <div class="status">
        <span id="arduinoStatus">Arduino: Checking...</span>
        <span id="cameraStatus">Camera: Checking...</span>
        <span id="modeStatus">Mode: MANUAL</span>
    </div>

    <div class="panel">
        <h2>Operating Mode</h2>
        <button id="manualButton" class="modeButton selected" onclick="changeMode('MANUAL')">MANUAL</button>
        <button id="autoButton" class="modeButton" onclick="changeMode('AUTONOMOUS')">AUTONOMOUS</button>
        <p id="modeMessage" class="hint">Manual mode is active. You control the robot.</p>
        <p class="hint">Autonomous mode monitors faces and raises alerts; it does not drive the motors.</p>
        
    </div>

    <div class="panel">
        <h2>Live Camera</h2>
        <img class="camera" id="cameraFeed" src="/video_feed" alt="Live camera feed">
        <br><br>
        <button id="fullscreenButton" onclick="fullscreenCamera()">Fullscreen</button>
    </div>

    <div class="panel">
        <h2>Face Recognition & Visual Tracking</h2>
        <p id="faceSummary">Waiting for recognition data...</p>
        <p class="hint">Tracking IDs remain attached to a detected face across nearby frames. Centre offsets show how far the face is from the camera image centre.</p>
        <hr style="border-color:#475569; margin:18px 0;">
        <h3>Target Selection</h3>
        <p id="targetStatus" class="hint">No target selected.</p>
        <div id="targetList"></div>
        <button id="releaseTargetButton" class="modeButton" onclick="releaseTarget()">RELEASE TARGET</button>
        <p class="hint">Selection is for visual monitoring only. It does not start or control robot movement.</p>
        <p id="knownPeople" class="hint">Known people: loading...</p>
        <p id="lastAlert" class="hint">Latest alert: none</p>
        <button id="reloadFacesButton" class="modeButton" onclick="reloadFaces()">Reload Enrolled Faces</button>
        <hr style="border-color:#475569; margin:18px 0;">
        <h3>Add a Known Person</h3>
        <p class="hint">Enter the person's name, keep only that consenting person in the camera view, then capture 10–20 samples with small head-angle changes. Each sample is saved immediately.</p>
        <input id="enrollName" type="text" maxlength="40" placeholder="Enter person's name"
               autocomplete="off"
               style="width:min(100%,340px); padding:12px; border-radius:8px; border:1px solid #64748b; background:#0f172a; color:white; margin:6px;">
        <br>
        <button id="showEnrollButton" class="modeButton" onclick="captureEnrollmentSample()">CAPTURE FACE SAMPLE</button>
        <p id="enrollStatus" class="hint" aria-live="polite">Ready to add a person.</p>
    </div>

    <div class="panel">
        <h2>Robot Movement</h2>
        <div class="joystick-area">
            <div id="joystick"><div id="stick"></div></div>
        </div>
        <p id="direction">Direction: STOP</p>
        <p class="hint">Drag the joystick to move. Release to stop.</p>
        <button id="stopButton" onclick="stopRobot()">EMERGENCY STOP</button>
        <p class="hint">Keyboard: W/A/S/D or arrow keys. Space or Escape = STOP.</p>
    </div>
</div>

<script>
const pad = document.getElementById("joystick");
const stick = document.getElementById("stick");
const directionText = document.getElementById("direction");
const modeMessage = document.getElementById("modeMessage");
let active = false;
let currentCommand = "STOP";
let heartbeat = null;
let pointerId = null;
let robotMode = "MANUAL";
const maxDistance = 75;

async function sendCommand(command) {
    try {
        const response = await fetch("/control", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({command})
        });
        const result = await response.json();
        if (!response.ok) {
            if (result.message) modeMessage.textContent = result.message;
            throw new Error(result.message || "Control request failed");
        }
        return true;
    } catch (error) {
        console.error(error);
        return false;
    }
}

function setCommand(command) {
    if (robotMode !== "MANUAL" && command !== "STOP") return;
    if (command === currentCommand) return;
    currentCommand = command;
    directionText.textContent = "Direction: " + command;
    sendCommand(command);
}

function startHeartbeat() {
    stopHeartbeat();
    heartbeat = setInterval(() => {
        if (active && robotMode === "MANUAL") sendCommand(currentCommand);
    }, 150);
}

function stopHeartbeat() {
    if (heartbeat) clearInterval(heartbeat);
    heartbeat = null;
}

function stopRobot() {
    active = false;
    pointerId = null;
    currentCommand = "STOP";
    directionText.textContent = "Direction: STOP";
    stick.style.left = "50%";
    stick.style.top = "50%";
    stopHeartbeat();
    sendCommand("STOP");
}

async function changeMode(mode) {
    stopRobot();
    try {
        const response = await fetch("/mode", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({mode})
        });
        const result = await response.json();
        if (!response.ok) throw new Error(result.message || "Could not change mode");

        robotMode = result.mode;
        document.getElementById("manualButton").classList.toggle("selected", robotMode === "MANUAL");
        document.getElementById("autoButton").classList.toggle("selected", robotMode === "AUTONOMOUS");
        pad.classList.toggle("disabled", robotMode !== "MANUAL");
        document.getElementById("modeStatus").textContent = "Mode: " + robotMode;
        modeMessage.textContent = result.message;
        if (robotMode !== "MANUAL") {
            currentCommand = "STOP";
            directionText.textContent = "Direction: STOP";
        }
    } catch (error) {
        modeMessage.textContent = error.message;
        console.error(error);
    }
}

function getCommand(dx, dy) {
    const deadZone = 22;
    if (Math.abs(dx) < deadZone && Math.abs(dy) < deadZone) return "STOP";
    if (Math.abs(dx) > Math.abs(dy)) return dx > 0 ? "RIGHT" : "LEFT";
    return dy > 0 ? "BACKWARD" : "FORWARD";
}

function moveJoystick(event) {
    if (!active || event.pointerId !== pointerId || robotMode !== "MANUAL") return;
    const rect = pad.getBoundingClientRect();
    let dx = event.clientX - (rect.left + rect.width / 2);
    let dy = event.clientY - (rect.top + rect.height / 2);
    const distance = Math.hypot(dx, dy);
    if (distance > maxDistance) {
        dx = dx / distance * maxDistance;
        dy = dy / distance * maxDistance;
    }
    stick.style.left = `calc(50% + ${dx}px)`;
    stick.style.top = `calc(50% + ${dy}px)`;
    setCommand(getCommand(dx, dy));
}

pad.addEventListener("pointerdown", event => {
    if (robotMode !== "MANUAL") return;
    active = true;
    pointerId = event.pointerId;
    pad.setPointerCapture(pointerId);
    startHeartbeat();
    moveJoystick(event);
});
pad.addEventListener("pointermove", moveJoystick);
pad.addEventListener("pointerup", event => {
    if (event.pointerId === pointerId) stopRobot();
});
pad.addEventListener("pointercancel", stopRobot);
pad.addEventListener("lostpointercapture", () => {
    if (active) stopRobot();
});

window.addEventListener("blur", stopRobot);
document.addEventListener("visibilitychange", () => {
    if (document.hidden) stopRobot();
});

const keys = {
    "w": "FORWARD", "arrowup": "FORWARD",
    "s": "BACKWARD", "arrowdown": "BACKWARD",
    "a": "LEFT", "arrowleft": "LEFT",
    "d": "RIGHT", "arrowright": "RIGHT"
};

window.addEventListener("keydown", event => {
    const key = event.key.toLowerCase();
    if (keys[key] && robotMode === "MANUAL") {
        event.preventDefault();
        active = true;
        startHeartbeat();
        setCommand(keys[key]);
    } else if (key === " " || key === "escape") {
        event.preventDefault();
        stopRobot();
    }
});
window.addEventListener("keyup", event => {
    const key = event.key.toLowerCase();
    if (keys[key]) stopRobot();
});

async function updateStatus() {
    try {
        const response = await fetch("/status");
        const data = await response.json();
        const a = document.getElementById("arduinoStatus");
        const c = document.getElementById("cameraStatus");
        a.textContent = "Arduino: " + data.arduino;
        a.className = data.arduino === "connected" ? "connected" : "disconnected";
        c.textContent = "Camera: " + (data.camera ? "Online" : "Offline");
        c.className = data.camera ? "connected" : "disconnected";
        if (data.mode !== robotMode) {
            robotMode = data.mode;
            document.getElementById("modeStatus").textContent = "Mode: " + robotMode;
            document.getElementById("manualButton").classList.toggle("selected", robotMode === "MANUAL");
            document.getElementById("autoButton").classList.toggle("selected", robotMode === "AUTONOMOUS");
            pad.classList.toggle("disabled", robotMode !== "MANUAL");
        }
    } catch (error) {
        console.error(error);
    }
}

function renderTargetControls(data) {
    const list = document.getElementById("targetList");
    const status = document.getElementById("targetStatus");
    const selected = data.selected_target_id;
    const faces = data.faces || [];
    list.replaceChildren();

    if (selected === null || selected === undefined) {
        status.textContent = "No target selected.";
    } else {
        status.textContent = `Selected target: #${selected}` +
            (data.target_missed_frames ? ` | temporarily not visible (${data.target_missed_frames}/75)` : " | visible");
    }

    faces.forEach(face => {
        const button = document.createElement("button");
        button.className = "modeButton";
        button.textContent = `SELECT ID ${face.track_id} — ${face.name}`;
        button.disabled = Number(selected) === Number(face.track_id);
        button.onclick = () => selectTarget(face.track_id);
        list.appendChild(button);
    });
    document.getElementById("releaseTargetButton").disabled =
        selected === null || selected === undefined;
}

async function selectTarget(trackId) {
    try {
        const response = await fetch("/api/target/select", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({track_id: trackId})
        });
        const result = await response.json();
        document.getElementById("targetStatus").textContent = result.message;
        if (response.ok) updateRecognition();
    } catch (error) {
        document.getElementById("targetStatus").textContent = "Could not select target.";
        console.error(error);
    }
}

async function releaseTarget() {
    try {
        const response = await fetch("/api/target/release", {method: "POST"});
        const result = await response.json();
        document.getElementById("targetStatus").textContent = result.message;
        updateRecognition();
    } catch (error) {
        document.getElementById("targetStatus").textContent = "Could not release target.";
        console.error(error);
    }
}

async function updateRecognition() {
    try {
        const response = await fetch("/api/recognition");
        const data = await response.json();
        const faces = data.faces || [];
        renderTargetControls(data);
        document.getElementById("faceSummary").textContent =
            faces.length ? faces.map(f =>
                `ID ${f.track_id}: ${f.name} (${f.state}, score ${f.score}) | ` +
                `centre offset X:${f.offset_x}px Y:${f.offset_y}px`
            ).join(" | ") : "No faces detected";
        document.getElementById("knownPeople").textContent =
            "Known people: " + ((data.known_people || []).join(", ") || "none enrolled");
        document.getElementById("lastAlert").textContent =
            "Latest alert: " + (data.last_alert || "none");
    } catch (error) {
        document.getElementById("faceSummary").textContent = "Recognition status unavailable";
    }
}

async function reloadFaces() {
    const response = await fetch("/api/reload_faces", {method: "POST"});
    const data = await response.json();
    document.getElementById("knownPeople").textContent =
        "Known people: " + ((data.known_people || []).join(", ") || "none enrolled");
    updateRecognition();
}

async function captureEnrollmentSample() {
    const nameInput = document.getElementById("enrollName");
    const status = document.getElementById("enrollStatus");
    const button = document.getElementById("showEnrollButton");
    const name = nameInput.value.trim();

    if (!name) {
        status.textContent = "Please enter a person's name first.";
        nameInput.focus();
        return;
    }

    button.disabled = true;
    status.textContent = "Capturing face sample...";
    try {
        const response = await fetch("/api/enroll/capture", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({name})
        });
        const result = await response.json();
        status.textContent = result.message || "Enrollment request completed.";
        if (!response.ok || !result.success) {
            status.textContent = result.message || "Could not capture sample.";
            return;
        }

        document.getElementById("knownPeople").textContent =
            "Known people: " + (result.known_people.join(", ") || "none enrolled");
        updateRecognition();
    } catch (error) {
        status.textContent = "Could not contact SERBOT. Check the dashboard connection.";
        console.error(error);
    } finally {
        button.disabled = false;
    }
}

function fullscreenCamera() {
    const cameraElement = document.getElementById("cameraFeed");
    if (cameraElement.requestFullscreen) cameraElement.requestFullscreen();
}

setInterval(updateStatus, 3000);
setInterval(updateRecognition, 1500);
updateStatus();
updateRecognition();

window.addEventListener("pagehide", () => {
    const data = new Blob(
        [JSON.stringify({command: "STOP"})],
        {type: "application/json"}
    );
    navigator.sendBeacon("/control", data);
});
</script>
</body>
</html>
"""


@app.route("/")
def index():
    return render_template_string(HTML)


@app.route("/video_feed")
def video_feed():
    return Response(
        generate_frames(),
        mimetype="multipart/x-mixed-replace; boundary=frame"
    )


def shutdown_resources():
    """Best-effort safe shutdown of motors, serial port and webcam."""
    try:
        send_motor_command("STOP")
    except Exception:
        pass
    try:
        if camera is not None and camera.isOpened():
            camera.release()
    except Exception:
        pass
    try:
        if arduino is not None and arduino.is_open:
            arduino.close()
    except Exception:
        pass


atexit.register(shutdown_resources)


if __name__ == "__main__":
    if not camera.isOpened():
        raise RuntimeError("USB webcam could not be opened")

    print("SERBOT dashboard starting")
    print("Default mode: MANUAL")
    print("Face recognition: enabled (prototype template matching)")
    print("Dashboard listening on all network interfaces: http://<PI-IP>:5000")
    app.run(host="0.0.0.0", port=5000, threaded=True)

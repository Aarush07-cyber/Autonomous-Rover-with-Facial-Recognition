SERBOT FINAL RASPBERRY PI PACKAGE
=================================

This package contains the Raspberry Pi application files:
- app.py: Flask dashboard, webcam stream, face recognition, enrollment,
  visual tracking, target selection/release, and Arduino manual motor control.
- face_engine.py: face detection and local template matching.
- face_tracker.py: visual tracking IDs.
- threat_logic.py: stable classification and unknown-face alerts.
- enroll.py: optional command-line enrollment helper.
- serbot.service: systemd startup service.

SERIAL PORT FIX
---------------
app.py is configured to use the stable Arduino USB identity observed on your
Raspberry Pi:
/dev/serial/by-id/usb-Arduino__www.arduino.cc__Arduino_14101-if00
This avoids depending on changing names such as /dev/ttyACM0 or /dev/ttyACM1.
If you replace the Arduino, its by-id name may differ. Check it with:
  ls -l /dev/serial/by-id/

INSTALL / UPDATE
----------------
1. Stop the service:
  sudo systemctl stop serbot.service

2. Back up your current application files:
  cd ~/webcam_project
  mkdir -p ~/serbot_backup_$(date +%Y%m%d_%H%M%S)
  cp app.py face_engine.py face_tracker.py threat_logic.py enroll.py ~/serbot_backup_$(date +%Y%m%d_%H%M%S)/ 2>/dev/null || true

3. Extract this ZIP in your home directory, then copy files:
  cd ~
  unzip -o serbot_final_package.zip
  cp ~/SERBOT_Final/*.py ~/webcam_project/

4. Install/refresh the systemd service:
  sudo cp ~/SERBOT_Final/serbot.service /etc/systemd/system/serbot.service
  sudo systemctl daemon-reload
  sudo systemctl enable serbot.service

5. Compile-check and start:
  cd ~/webcam_project
  .venv/bin/python -m py_compile app.py face_engine.py face_tracker.py threat_logic.py enroll.py
  sudo systemctl start serbot.service
  sudo systemctl status serbot.service --no-pager

6. Follow logs if needed:
  sudo journalctl -u serbot.service -f

NETWORK ACCESS
--------------
The Flask server listens on 0.0.0.0:5000. Find the Pi's Wi-Fi IPv4 address:
  ip -4 addr show wlan0
Open http://PI_WIFI_IP:5000 from another device on the same Wi-Fi/hotspot.
The IP may change when the Pi reconnects; use the current wlan0 address.

SAFETY / OPERATING NOTES
------------------------
- The application starts in MANUAL mode after a restart.
- AUTONOMOUS mode is monitoring-only; it does not drive the motors.
- Target selection is for visual monitoring only; it does not make the robot follow.
- Keep the existing Arduino firmware installed. It provides the ultrasonic
  obstacle checks and serial watchdog. This package does not replace that firmware.
- Test with wheels raised and keep the emergency stop available.
- Face matching is a prototype, not reliable identity verification.
- The dashboard does not include authentication. Use only on a trusted private
  network; do not expose port 5000 directly to the public internet.

DEPENDENCIES
------------
Use the existing project virtual environment. Check imports with:
  cd ~/webcam_project
  .venv/bin/python -c "import cv2, numpy, flask, serial; print('Dependencies OK')"
Do not install another OpenCV build if the current camera application is working.

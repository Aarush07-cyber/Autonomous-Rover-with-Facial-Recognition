"""Enroll a consenting person into SERBOT's local face-template database.

Stop app.py first so this script can own the USB webcam.
Usage: python enroll.py "Person_Name"
Press SPACE to save a sample; capture 10-15 samples with small head-angle changes.
Press Q or ESC to quit.
"""
import sys
import cv2
from face_engine import FaceEngine


def main():
    if len(sys.argv) < 2:
        print('Usage: python enroll.py "Person_Name"')
        raise SystemExit(2)

    name = sys.argv[1]
    engine = FaceEngine()
    cap = cv2.VideoCapture(0, cv2.CAP_V4L2)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    if not cap.isOpened():
        raise RuntimeError("Could not open webcam. Stop the Flask app first.")

    saved = 0
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                print("Camera frame unavailable")
                break

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = engine.detector.detectMultiScale(
                gray, scaleFactor=1.15, minNeighbors=5, minSize=(70, 70)
            )
            chosen = None
            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x+w, y+h), (40, 200, 80), 2)
                chosen = gray[y:y+h, x:x+w]

            cv2.putText(frame, f"Enrolling: {name} | Samples: {saved}",
                        (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.6,
                        (255, 255, 255), 2)
            cv2.putText(frame, "SPACE: save face sample | Q: finish",
                        (10, 52), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                        (255, 255, 255), 1)
            cv2.imshow("SERBOT Face Enrollment", frame)

            key = cv2.waitKey(1) & 0xFF
            if key == ord("q") or key == 27:
                break
            if key == 32:
                if chosen is None:
                    print("No face detected. Move into view and try again.")
                    continue
                engine.add_enrollment_sample(name, chosen)
                saved += 1
                print(f"Saved sample {saved} for {name}")

    finally:
        cap.release()
        cv2.destroyAllWindows()

    print(f"Enrollment finished. Saved {saved} new samples.")
    print("Known-face data is stored locally in ./known_faces/")


if __name__ == "__main__":
    main()
